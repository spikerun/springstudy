package com.example.demo.Model;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Created by sewoo15@naver.com on 30/12/2019
 * Github : https://github.com/spikerun/javaScriptStudy
 */

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Url {

    @Id
    @GeneratedValue
    private Long id;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String crc;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String url;

    @Builder
    public Url(String crc, String url){
        this.crc = crc;
        this.url = url;
    }
}
