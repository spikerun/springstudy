package com.example.demo.WController;

import com.example.demo.Model.Url;
import com.example.demo.Model.UrlReposrtory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;

/**
 * Created by sewoo15@naver.com on 30/12/2019
 * Github : https://github.com/spikerun/javaScriptStudy
 */

@Controller
public class Wcontroller {

    @Autowired
    UrlReposrtory urlReposrtory;

    @GetMapping(value = {"/e/{dsmain}"})
    public RedirectView dcmain(@PathVariable String dsmain) {

        List<Url> list = urlReposrtory.findAll();

        String redirectUrl = "";
        Url url;

        for (int i=0; i < list.size(); ++i){
            url = list.get(i);

            if (dsmain.equals(url.getCrc())){
                redirectUrl = url.getUrl();

                break;
            }
        }

        return new RedirectView(redirectUrl);
    }

    @GetMapping(value = {"/Drname"})
    public String index(){
        return "Drname";
    }
} 
