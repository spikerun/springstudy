package com.example.demo.RController;

import com.example.demo.Model.Url;
import com.example.demo.Model.UrlReposrtory;
import com.example.demo.Utils.Encrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sewoo15@naver.com on 30/12/2019
 * Github : https://github.com/spikerun/javaScriptStudy
 */
@RestController
public class RController {

    @Autowired
    UrlReposrtory urlReposrtory;

    @PostMapping(value = {"/encrypt"})
    public Map getEncrypt(@RequestBody Map params){
        String url = (String) params.get("url");
        String crc = Encrypt.getCRC(url);

        saveDB(crc, url);

        return returnData(crc, url);
    }

    public void saveDB(String crc, String url){
        Url Url = new Url(crc, url);
        urlReposrtory.save(Url);
    }

    public Map returnData(String crc, String url){
        Map result = new HashMap<>();

        result.put("hash", crc);
        result.put("link", url);

        return result;
    }

    @PostMapping(value = {"/getList"})
    public List<Url> getList(){
        return urlReposrtory.findAll();
    }

}
