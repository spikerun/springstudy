package com.example.demo.Utils;

import java.util.zip.CRC32;

/**
 * Created by sewoo15@naver.com on 30/12/2019
 * Github : https://github.com/spikerun/javaScriptStudy
 */

public class Encrypt {
    public static String getCRC(String dsmain){
        byte[] bytes = dsmain.getBytes();
        CRC32 crc = new CRC32();
        crc.update(bytes);
        return Long.toHexString(crc.getValue());
    }
}