package com.example.demo.Model;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by sewoo15@naver.com on 30/12/2019
 * Github : https://github.com/spikerun/javaScriptStudy
 */
public interface UrlReposrtory extends JpaRepository<Url, Long> {

}
