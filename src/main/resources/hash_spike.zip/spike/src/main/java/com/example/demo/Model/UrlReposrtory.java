package com.example.demo.Model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UrlReposrtory extends JpaRepository<Url, Long> {

}

