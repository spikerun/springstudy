package com.example.demo.Utils;

import java.util.zip.CRC32;

public class Encrypt {
    public static String getCRC(String dsmain) {
        byte[] bytes = dsmain.getBytes();
        CRC32 crc = new CRC32();
        crc.update(bytes);
        return Long.toHexString(crc.getValue());
    }
}
