package com.example.demo.Model;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Email;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Url {

    @Id
    @GeneratedValue
    private Long id;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String crc;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String url;

//    @Column(columnDefinition = "TEXT", nullable = false)
//    private Long time;

    @Builder
    public Url(String crc, String url) {
        this.crc = crc;
        this.url = url;
    }

}
