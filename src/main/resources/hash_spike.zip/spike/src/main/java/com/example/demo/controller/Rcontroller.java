package com.example.demo.controller;

import com.example.demo.Model.Url;
import com.example.demo.Model.UrlReposrtory;
import com.example.demo.Utils.Encrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Email;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * RESTful 한 API 용도로 만든 컨트롤러
 */
@RestController
public class Rcontroller {

    @Autowired
    UrlReposrtory urlReposrtory;

    /**
     * encrypt 시키는 메서드
     * @pre-condition 프로토콜 검증이 완료되어 있어야 함 (Client 에서 미리 해야 함)
     * @param params Clinet 에서 보낸 데이터
     * @return encrypt 시킨 URL 결과
     */
    @PostMapping(value = {"/encrypt"})
    public Map getEncrypt(@RequestBody Map params) {
        String url = (String) params.get("url");

        /**
         * encrypt 된 URL
         */
        String crc = Encrypt.getCRC(url);

        saveDB(crc, url);

        deleteDB(crc, url);
        return returnData(crc, url);
    }

    public void saveDB(String crc, String url) {
        /**
         * Url 인스턴스를 생성
         */
        Url Url = new Url(crc, url);

        /**
         * DB insert 실행
         */
        urlReposrtory.save(Url);
    }

    /**
     * 클라이언트에 반환하는 값
     * @param crc 암호화된 값
     * @param url 암호화하기 이전 값A
     * @return 클라이언트에 반환하는 값
     */
    public Map returnData(String crc, String url) {

        Map result = new HashMap<>();

        result.put("hash", crc);
        result.put("link", url);

        return result;
    }

    /**
     * 리스트 가져오는 부분
     * @return
     */
    @PostMapping(value = {"/getList"})
    public List<Url> getList() {
        return urlReposrtory.findAll();
    }

    public void deleteDB(String crc,String url){

        Url Url = new Url(crc, url);
        urlReposrtory.delete(Url);
    }
}