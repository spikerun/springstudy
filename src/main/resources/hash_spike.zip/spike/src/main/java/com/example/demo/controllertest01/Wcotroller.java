package com.example.demo.controllertest01;

import com.example.demo.Model.Url;
import com.example.demo.Model.UrlReposrtory;
import lombok.var;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Date;
import java.util.List;

/**
 * Web Page 만 컨트롤 하는 용도
 */
@Controller
public class Wcotroller {

    @Autowired
    UrlReposrtory urlReposrtory;

    @GetMapping(value = {"/e/{dsmain}"})
    public RedirectView dcmain(@PathVariable String dsmain){

        /**
         * DB 에 있는 데이터들을 모두 추출해
         */
        List<Url> list = urlReposrtory.findAll();

        /**
         * 키값(dsmain) 을 가진 URL 을 찾자
         */
        String redirectUrl = "";
        Url url;

        for (int i = 0; i < list.size(); ++i) {
            url = list.get(i);

            if (dsmain.equals(url.getCrc())) {
                redirectUrl = url.getUrl();

                break;
            }
        }

        /**
         * 찾은 URL 을 리다이렉트 시키자
         */
        return new RedirectView(redirectUrl);
    }

    @GetMapping(value = {"/dsmain"})
    public String index() {
        return "dsmain";
    }




}
