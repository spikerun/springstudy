package com.example.demo.spike;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class spike01 {

    @GetMapping(value = {"/spike"})
    public String spike01(){
        return "스파이크01";
    }

    @GetMapping(value = {"/spike02"})
    public String spike02(){
        return "스파이크02";
    }


    public String spike03(){
        return "스파이크03";
    }

    @GetMapping(value = {"/spike04"})
    @Override
    public String toString() {
        return super.toString();
    }
}
