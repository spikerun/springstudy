package com.example.demo.spike;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Apple {
    @Autowired
    PostReposrtory postReposrtory;

    @GetMapping(value = {"/apple"})
    public String apple(){
        return "KMS";
    }

    @GetMapping(value = {"/insert"})
    public String insert(){

        Post post = new Post("TEST TITLE", "TEST CONTENTS", "AUTHOR");
        postReposrtory.save(post);

        return "KMS";
    }

}