package com.example.demo.spike;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Webpage {

    @GetMapping(value = {"/Index"})
    public String Index(){
        return "TEST";
    }

}
