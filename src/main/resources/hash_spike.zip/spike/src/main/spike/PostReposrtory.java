package com.example.demo.spike;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PostReposrtory extends JpaRepository<Post, Long> {

}
